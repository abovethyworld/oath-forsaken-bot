// Recruitment applications — three types: ironman, main, guest.
// On member join: opens a private application channel with three buttons.
// Iron applicants pick their total level bracket from a dropdown, then fill a modal.
// Main/guest applicants go straight to a modal (no total level asked).
// Submit -> the bot opens a forum post in the applications forum titled
// "<Type> App from <username>" with the answers, so staff can discuss in the
// thread. Approve / Deny buttons live on the post's starter message.
// Approve assigns the right member role (Iron Sworn/Unbound/Guest) + Initiate
// seniority, renames the post to "... - Approved", and locks it.
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  EmbedBuilder,
  ModalBuilder,
  PermissionFlagsBits,
  StringSelectMenuBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require('discord.js');
const config = require('./config');
const store = require('./store');

const DAY_MS = 24 * 3600 * 1000;
const ZAMORAK_RED = 0x6b0e0e;

// Total-level brackets mirror the clan's rank ladder.
const TOTAL_LEVEL_BRACKETS = [
  { value: 'maxed', label: 'Maxed [2376]' },
  { value: 'zamorakian', label: 'Zamorakian [2300-2375]' },
  { value: 'wrath', label: 'Wrath [2150-2299]' },
  { value: 'destroyer', label: 'Destroyer [2000-2149]' },
  { value: 'unholy', label: 'Unholy [1850-1999]' },
  { value: 'skulled', label: 'Skulled [1650-1849]' },
  { value: 'death', label: 'Death [1450-1649]' },
  { value: 'imp', label: 'Imp [1250-1449]' },
  { value: 'goblin', label: 'Goblin [1000-1249]' },
  { value: 'necromancer', label: 'Necromancer [500-999]' },
  { value: 'wizard', label: 'Wizard [0-499]' },
];

function bracketLabel(value) {
  const b = TOTAL_LEVEL_BRACKETS.find((x) => x.value === value);
  return b ? b.label : value;
}

function accountAgeDays(user) {
  return Math.floor((Date.now() - user.createdAt.getTime()) / DAY_MS);
}

function appTypes() {
  return config.recruit?.types || {};
}

async function onMemberJoin(member) {
  const rc = config.recruit;
  if (!rc) return;
  const types = appTypes();
  const guild = member.guild;

  const overwrites = [
    { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
    {
      id: member.id,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
    },
  ];
  for (const rid of config.tickets.staffRoleIds || []) {
    overwrites.push({
      id: rid,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
    });
  }

  const safeName = member.user.username.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 20) || 'user';
  const channel = await guild.channels
    .create({
      name: `application-${safeName}`,
      type: ChannelType.GuildText,
      parent: config.tickets.categoryId || null,
      permissionOverwrites: overwrites,
      reason: `Application for ${member.user.tag}`,
    })
    .catch(() => null);
  if (!channel) return;
  store.setApplication(guild.id, member.id, channel.id);

  const embed = new EmbedBuilder()
    .setTitle('📝 Clan Application')
    .setDescription(
      `Welcome, ${member}! To join **${guild.name}**, pick the application that fits you.\n\n` +
        `**Ironman** — you play an ironman and want full clan membership (ranks, bingos, comps).\n` +
        `**Main** — you play a main; you can hang out, earn seniority, and join casual events.\n` +
        `**Guest** — you're just visiting or here for a friend.\n\n` +
        `Staff review every application — we'll ping you here when there's a decision.`
    )
    .setColor(ZAMORAK_RED);

  const row = new ActionRowBuilder();
  for (const [key, t] of Object.entries(types)) {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(`apply:type:${key}`)
        .setLabel(t.buttonLabel || t.label)
        .setStyle(ButtonStyle.Primary)
        .setEmoji(t.emoji || '📝')
    );
  }
  await channel.send({ content: `${member}`, embeds: [embed], components: [row] }).catch(() => {});
}

// Iron applicants pick a total-level bracket first (modals can't hold dropdowns).
async function showTotalLevelSelect(interaction) {
  const menu = new StringSelectMenuBuilder()
    .setCustomId('apply:total')
    .setPlaceholder('What is your total level?')
    .addOptions(TOTAL_LEVEL_BRACKETS.map((b) => ({ label: b.label, value: b.value })));
  const row = new ActionRowBuilder().addComponents(menu);
  await interaction.reply({
    content: 'Pick your total level bracket, then answer a few questions.',
    components: [row],
    ephemeral: true,
  });
}

async function showApplicationModal(interaction, type, totalBracket) {
  const types = appTypes();
  const t = types[type];
  if (!t) return;
  // customId: apply:modal:<type>:<bracket|none>  (keep under 100 chars)
  const modal = new ModalBuilder()
    .setCustomId(`apply:modal:${type}:${totalBracket || 'none'}`)
    .setTitle(`${t.label} Application`);
  for (const q of t.questions || []) {
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId(q.id)
          .setLabel(q.label)
          .setStyle(q.style === 'paragraph' ? TextInputStyle.Paragraph : TextInputStyle.Short)
          .setRequired(!!q.required)
          .setMaxLength(q.style === 'paragraph' ? 500 : 100)
      )
    );
  }
  await interaction.showModal(modal);
}

async function handleModalSubmit(interaction) {
  // customId: apply:modal:<type>:<bracket|none>
  const parts = interaction.customId.split(':');
  if (parts[0] !== 'apply' || parts[1] !== 'modal') return;
  const [, , type, bracket] = parts;
  const types = appTypes();
  const t = types[type];
  if (!t) return;

  const answers = {};
  for (const q of t.questions || []) {
    answers[q.id] = interaction.fields.getTextInputValue(q.id);
  }

  await interaction.deferReply({ ephemeral: true });

  const rc = config.recruit;
  const ageDays = accountAgeDays(interaction.user);
  const ageOk = ageDays >= (rc.minAccountAgeDays || 30);
  const forum = interaction.guild.channels.cache.get(rc.applicationsChannelId);
  if (!forum || forum.type !== ChannelType.GuildForum) {
    await interaction.editReply('Applications forum is not set up — tell staff.');
    return;
  }

  const lines = [`**Application type:** ${t.label}`];
  if (type === 'iron' && bracket && bracket !== 'none') {
    lines.push(`**Total level:** ${bracketLabel(bracket)}`);
  }
  for (const q of t.questions || []) {
    lines.push(`**${q.label}:** ${answers[q.id]}`);
  }
  const embed = new EmbedBuilder()
    .setTitle(`Application — ${interaction.user.tag}`)
    .setDescription(lines.join('\n'))
    .addFields(
      {
        name: 'User',
        value: `<@${interaction.user.id}> (${interaction.user.tag})`,
      },
      {
        name: 'Account age',
        value: ageOk ? `✅ ${ageDays} days (meets ${rc.minAccountAgeDays}-day minimum)` : `⚠️ **${ageDays} days** — under the ${rc.minAccountAgeDays}-day minimum`,
      }
    )
    .setColor(ageOk ? ZAMORAK_RED : 0xffa500)
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`apply:approve:${interaction.user.id}:${type}`).setLabel('Approve').setStyle(ButtonStyle.Success).setEmoji('✅'),
    new ButtonBuilder().setCustomId(`apply:deny:${interaction.user.id}:${type}`).setLabel('Deny').setStyle(ButtonStyle.Danger).setEmoji('❌')
  );

  const postName = `${t.label} App from ${interaction.user.username}`;
  const thread = await forum.threads
    .create({
      name: postName.slice(0, 100),
      message: { embeds: [embed], components: [row] },
      reason: `Application from ${interaction.user.tag}`,
    })
    .catch(() => null);

  if (thread) {
    await interaction.editReply('Application submitted! Staff will review it soon.');
  } else {
    await interaction.editReply('Could not open your application thread — tell staff.');
  }

  // Mark this channel as submitted so it isn't reused
  store.setApplicationSubmitted(interaction.guildId, interaction.user.id);
}

function isStaff(interaction) {
  const staffIds = config.tickets.staffRoleIds || [];
  return (
    interaction.member.roles.cache.some((r) => staffIds.includes(r.id)) ||
    interaction.memberPermissions.has(PermissionFlagsBits.Administrator)
  );
}

async function handleDecision(interaction) {
  // customId: apply:approve:<userId>:<type> or apply:deny:<userId>:<type>
  const [, decision, userId, type] = interaction.customId.split(':');
  if (!isStaff(interaction)) {
    await interaction.reply({ content: 'Staff only.', ephemeral: true });
    return;
  }
  const types = appTypes();
  const t = types[type] || {};
  const guild = interaction.guild;
  const target = await guild.members.fetch(userId).catch(() => null);
  const thread = interaction.channel;

  await interaction.deferReply({ ephemeral: true });

  if (decision === 'approve' && target) {
    if (t.roleId) await target.roles.add(t.roleId).catch(() => {});
    // New members start at the bottom of the tenure ladder.
    const entry = (config.seniorityRanks || []).find((r) => r.minMonths === 0);
    if (entry) await target.roles.add(entry.roleId, 'New member tenure rank').catch(() => {});
    await target.send(`🎉 Your **${t.label}** application to **${guild.name}** was approved! Head to the roles channel to pick your ping roles and introduce yourself.`).catch(() => {});
  } else if (target) {
    await target.send(`Thanks for applying to **${guild.name}** — staff decided not to move forward this time. You're welcome to reapply later.`).catch(() => {});
  }

  // Rename the post like Raven's Watch: "<Type> App from <user> - Approved"
  if (thread && thread.isThread()) {
    const base = thread.name.replace(/ - (Approved|Denied)$/, '');
    await thread.setName(`${base} - ${decision === 'approve' ? 'Approved' : 'Denied'}`.slice(0, 100)).catch(() => {});
    await thread.setLocked(true).catch(() => {});
    await thread.setArchived(true).catch(() => {});
  }

  await interaction.editReply(decision === 'approve' ? `Approved <@${userId}> as ${t.label || type}.` : `Denied <@${userId}>.`);

  // Close their private application channel
  const appChannelId = store.getApplication(guild.id, userId);
  if (appChannelId) {
    const ch = guild.channels.cache.get(appChannelId);
    store.removeApplication(guild.id, userId);
    if (ch) setTimeout(() => ch.delete('Application decided').catch(() => {}), 5000);
  }

  const log = guild.channels.cache.get(config.tickets.logChannelId);
  if (log) {
    await log.send(`Application **${decision}d** (${t.label || type}): <@${userId}> by ${interaction.user.tag}`).catch(() => {});
  }
}

async function handleApplyButton(interaction) {
  // customId: apply:type:<type> | apply:approve:... | apply:deny:...
  const parts = interaction.customId.split(':');
  const action = parts[1];
  if (action === 'type') {
    const type = parts[2];
    if (type === 'iron') return showTotalLevelSelect(interaction);
    return showApplicationModal(interaction, type, null);
  }
  if (action === 'approve' || action === 'deny') return handleDecision(interaction);
}

async function handleTotalSelect(interaction) {
  // customId: apply:total
  if (interaction.customId !== 'apply:total') return;
  const bracket = interaction.values[0];
  await showApplicationModal(interaction, 'iron', bracket);
}

module.exports = { onMemberJoin, handleApplyButton, handleModalSubmit, handleTotalSelect };
