// Ticket system: /setup-tickets posts an "Open a Ticket" panel.
// Clicking it creates a private channel (user + staff only) with a Close button.
// Closing posts a transcript to the log channel and deletes the ticket channel.
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  EmbedBuilder,
  PermissionFlagsBits,
  SlashCommandBuilder,
} = require('discord.js');
const config = require('./config');
const store = require('./store');

async function setupTickets(interaction) {
  await interaction.deferReply({ ephemeral: true });
  const t = config.tickets;
  const channel = interaction.guild.channels.cache.get(t.panelChannelId);
  if (!channel) {
    await interaction.editReply('Ticket panel channel not found. Check config.tickets.panelChannelId.');
    return;
  }
  const embed = new EmbedBuilder()
    .setTitle(t.title)
    .setDescription(t.description)
    .setColor(t.color ?? 0x5865f2);
  if (t.banner) embed.setImage(t.banner);
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('ticket:create')
      .setLabel(t.buttonLabel || 'Open a Ticket')
      .setStyle(ButtonStyle.Primary)
      .setEmoji('🎫')
  );
  await channel.send({ embeds: [embed], components: [row] });
  await interaction.editReply(`Ticket panel posted in ${channel}.`);
}

async function createTicket(interaction) {
  const t = config.tickets;

  const existingId = store.getTicket(interaction.guildId, interaction.user.id);
  if (existingId) {
    const existing = interaction.guild.channels.cache.get(existingId);
    if (existing) {
      await interaction.reply({ content: `You already have an open ticket: ${existing}`, ephemeral: true });
      return;
    }
    store.removeTicket(interaction.guildId, interaction.user.id); // stale record
  }

  await interaction.deferReply({ ephemeral: true });

  const overwrites = [
    { id: interaction.guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
    {
      id: interaction.user.id,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
    },
  ];
  for (const roleId of t.staffRoleIds || []) {
    overwrites.push({
      id: roleId,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.ManageMessages,
      ],
    });
  }

  const safeName = interaction.user.username.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 20) || 'user';
  let channel;
  try {
    channel = await interaction.guild.channels.create({
      name: `ticket-${safeName}`,
      type: ChannelType.GuildText,
      parent: t.categoryId || null,
      permissionOverwrites: overwrites,
      reason: `Ticket opened by ${interaction.user.tag}`,
    });
  } catch (err) {
    await interaction.editReply('Could not create the ticket channel. Make sure I have the **Manage Channels** permission.');
    return;
  }

  store.setTicket(interaction.guildId, interaction.user.id, channel.id);

  const staffPings = (t.staffRoleIds || []).map((r) => `<@&${r}>`).join(' ');
  const embed = new EmbedBuilder()
    .setTitle('Ticket opened')
    .setDescription(t.introMessage || 'Staff will be with you shortly.')
    .setColor(t.color ?? 0x5865f2);
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('ticket:close')
      .setLabel('Close Ticket')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('🔒')
  );
  await channel.send({
    content: `${interaction.user} ${staffPings}`.trim(),
    embeds: [embed],
    components: [row],
  });

  await interaction.editReply(`Ticket created: ${channel}`);
}

function isStaff(interaction) {
  const staffIds = config.tickets.staffRoleIds || [];
  return (
    interaction.member.roles.cache.some((r) => staffIds.includes(r.id)) ||
    interaction.memberPermissions.has(PermissionFlagsBits.Administrator)
  );
}

async function closeTicket(interaction) {
  const channel = interaction.channel;
  const ownerId = store.getTicketOwner(interaction.guildId, channel.id);

  if (!ownerId) {
    await interaction.reply({ content: 'This only works inside a ticket channel.', ephemeral: true });
    return;
  }
  if (interaction.user.id !== ownerId && !isStaff(interaction)) {
    await interaction.reply({ content: 'Only staff or the ticket owner can close this.', ephemeral: true });
    return;
  }

  await interaction.reply('Closing ticket — saving transcript…');

  let transcript = `Ticket transcript — #${channel.name}\nClosed by ${interaction.user.tag} at ${new Date().toISOString()}\n\n`;
  const messages = await channel.messages.fetch({ limit: 100 }).catch(() => null);
  if (messages) {
    const sorted = [...messages.values()].sort((a, b) => a.createdTimestamp - b.createdTimestamp);
    for (const m of sorted) {
      transcript += `[${m.createdAt.toISOString()}] ${m.author.tag}: ${m.content || '(attachment/embed)'}\n`;
    }
  }

  const log = interaction.guild.channels.cache.get(config.tickets.logChannelId);
  if (log) {
    await log
      .send({
        content: `Transcript for #${channel.name} (owner: ${ownerId ? `<@${ownerId}>` : 'unknown'})`,
        files: [{ attachment: Buffer.from(transcript, 'utf8'), name: `transcript-${channel.name}.txt` }],
      })
      .catch(() => {});
  }

  store.removeTicket(interaction.guildId, ownerId);
  setTimeout(() => channel.delete('Ticket closed').catch(() => {}), 3000);
}

async function handleTicketButton(interaction) {
  const [, action] = interaction.customId.split(':');
  if (action === 'create') return createTicket(interaction);
  if (action === 'close') return closeTicket(interaction);
}

const commands = [
  {
    data: new SlashCommandBuilder()
      .setName('setup-tickets')
      .setDescription('Post the ticket panel (Admin only)')
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    run: setupTickets,
  },
  {
    data: new SlashCommandBuilder()
      .setName('close')
      .setDescription('Close this ticket (staff or ticket owner)'),
    run: closeTicket,
  },
];

module.exports = { commands, handleTicketButton };
